useMongodb = True
hostname = "datascience01"
user = None
password = None
host = None